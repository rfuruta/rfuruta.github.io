This is the implementation of our papers: 
[1] R. Furuta, S. Ikehata, T. Yamasaki, and K. Aizawa, "Efficiency-enhanced cost-volume filtering featuring coarse-to-fine strategy," MTAP, 2017. 
[2] R. Furuta, S. Ikehata, T. Yamasaki, and K. Aizawa, "Coarse-to-fine strategy for efficient cost-volume filtering," in ICIP, 2014. 

If you use our code we request that you cite the papers [1] and [2].

Files: 
CtF_Grid.cpp is the coarse-to-fine CVF with regular grids dividing, and CtF_SLIC.cpp is the one with SLIC super-pixels.

Dependency: 
OpenCV2.

Note that this implementation produces slightly different results from the ones reported in our papers because this is the rewritten version of our method for the readability.

This implementation is based on the following MATLAB code:
[3] C. Rhemann, A. Hosni, M. Bleyer, C. Rother, M. Gelautz, "Fast Cost-Volume Filtering for Visual Correspondence and Beyond," in CVPR, 2011.
https://github.com/coder89/stereo/tree/master/Matlab/testy

SLIC.cpp and SLIC.h were obtained from the following: 
[4] R. Achanta, A. Shaji, K. Smith, A. Lucchi, P. Fua and S. Süsstrunk, "SLIC Superpixels Compared to State-of-the-Art Superpixel Methods," TPAMI, vol. 34, no. 11, pp. 2274-2282, Nov. 2012.
http://ivrl.epfl.ch/files/content/sites/ivrg/files/supplementary_material/RK_SLICsuperpixels/SLICSuperpixels_VC2008_SLICO_15Jun2013.zip
