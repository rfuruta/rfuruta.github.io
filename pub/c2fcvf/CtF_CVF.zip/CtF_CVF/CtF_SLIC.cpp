#include <stdio.h>
#include <highgui.h>
#include <cv.h>
#include <iostream>
#include <opencv2/core/core.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <math.h>
#include <algorithm>
#include <string.h>
#include <time.h>
#include <stdlib.h>
#include "SLIC.h"


// location of super-pixels
struct SP_loc {
    int up;
    int down;
    int left;
    int right;
  };


// function which gets the location of super-pixels
void getSPloc(cv::Mat& SPmap, struct SP_loc* SP_locs, int numSPs){
  int x, y;
  for(x = 0; x < numSPs; x++){
    SP_locs[x].up = SPmap.rows;
    SP_locs[x].down = 0;
    SP_locs[x].left = SPmap.cols;
    SP_locs[x].right = 0;
  }

  for(y = 0; y < SPmap.rows; y++){
    for(x = 0; x < SPmap.cols; x++){
      if(SP_locs[SPmap.at<int>(y,x)].up > y){
	SP_locs[SPmap.at<int>(y,x)].up = y;
      }
      if(SP_locs[SPmap.at<int>(y,x)].down < y){
	SP_locs[SPmap.at<int>(y,x)].down = y;
      }
      if(SP_locs[SPmap.at<int>(y,x)].left > x){
	SP_locs[SPmap.at<int>(y,x)].left = x;
      }
      if(SP_locs[SPmap.at<int>(y,x)].right < x){
	SP_locs[SPmap.at<int>(y,x)].right = x;
      }
    }
  }
}



// function which makes super-pixels
void PerformSLICO(cv::Mat *input, int k, double m, cv::Mat *output, int *numSPs){
  int point, y, x;
  int sz = input->rows*input->cols;

  unsigned int* pbuff = new unsigned int[sz];

  for(y = 0; y < input->rows; y++){
    for(x = 0; x < input->cols; x++){
      point = y*input->step + x*input->elemSize();
      pbuff[y*input->cols + x] = (unsigned int)input->data[point] + ((unsigned int)input->data[point+1] << 8) + ((unsigned int)input->data[point+2] << 16);
    }
  }

  int* klabels = new int[sz];
  int numlabels(0);

  SLIC segment;
  segment.PerformSLICO_ForGivenK(pbuff, input->cols, input->rows, klabels, numlabels, k, m);

  *numSPs = numlabels;

  cv::Mat outTemp = cv::Mat(input->rows, input->cols, CV_32S);

  for(y = 0; y < input->rows; y++){
    for(x = 0; x < input->cols; x++){
      point = y*input->cols + x;
      outTemp.at<int>(y,x) = klabels[point];
    }
  }


  *output = cv::Mat(input->rows, input->cols, CV_32S);
  *output = outTemp;

}







// weighted median filtering for post-process
void weightedMedian(cv::Mat *left_img, cv::Mat *disp_img, cv::Mat *occ_img, int winsize, double gamma_c, double gamma_p, int numDisp, cv::Mat *medianFiltered){

  cv::Mat occ = *occ_img;

  int h = left_img->rows;
  int w = left_img->cols;
  int c = left_img->channels();

  clock_t t0, t1;
  t0 = clock();

  cv::Mat left_img_float = *left_img;
  left_img_float.convertTo(left_img_float, CV_32F);
  cv::Mat colimg;

  cv::medianBlur(left_img_float, colimg, 3);
  colimg.convertTo(colimg, CV_64F);

  int radius = winsize/2;

  cv::Mat medianFiltered_tmp = cv::Mat::zeros(h, w, CV_32S);

  cv::Mat disp_img_copy = *disp_img;
  double hist_sum;
  double maxDispVal_tmp;
  int maxDispVal;
  int y, x, i, j;
  int patch_left, patch_right, patch_up, patch_down;
  int patch_h, patch_w;
  
  cv::Mat *colimg_BGR = new cv::Mat[3];
  cv::split(colimg, colimg_BGR);
  double centercol_R, centercol_G, centercol_B;
  cv::Mat centercol1, centercol2, centercol3, tempy, patchYinds, tempx, patchXinds, curPatch1, curPatch2, curPatch3, coldiff, xones, yones, sdiff, temp1, temp2;
  cv::Mat maskVals, dispVals;
  double *hist = new double[numDisp];
  double *hist_cumsum = new double[numDisp];
  
  for(y = 0; y < h; y++){
    for(x = 0; x < w; x++){
      if(occ.at<unsigned char>(y,x) > 0){

	patch_up = std::max(0,y-radius);
	patch_down = std::min(h-1,y+radius);
	patch_h = patch_down - patch_up + 1;
	patch_left = std::max(0,x-radius);
	patch_right = std::min(w-1,x+radius);
	patch_w = patch_right - patch_left + 1;
	
	
	
	
	
	centercol_R = colimg_BGR[2].at<double>(y,x);
	centercol_G = colimg_BGR[1].at<double>(y,x);
	centercol_B = colimg_BGR[0].at<double>(y,x);
	
	centercol1 = cv::Mat(patch_h, patch_w, CV_64F);
	centercol2 = cv::Mat(patch_h, patch_w, CV_64F);
	centercol3 = cv::Mat(patch_h, patch_w, CV_64F);
	
	cv::repeat(centercol_R, patch_h, patch_w, centercol1);
	cv::repeat(centercol_G, patch_h, patch_w, centercol2);
	cv::repeat(centercol_B, patch_h, patch_w, centercol3);
	
	tempy = cv::Mat(patch_h, 1, CV_32S);
	patchYinds = cv::Mat(patch_h, patch_w, CV_32S);
	for(i = 0; i < patch_h; i++){
	  tempy.at<int>(i,0) = i + patch_up;
	}
	cv::repeat(tempy, 1, patch_w, patchYinds);
	
	tempx = cv::Mat(1, patch_w, CV_32S);
	patchXinds = cv::Mat(patch_h, patch_w, CV_32S);
	for(j = 0; j < patch_w; j++){
	  tempx.at<int>(0,j) = j + patch_left;
	}
	cv::repeat(tempx, patch_h, 1, patchXinds);
	
	curPatch1 = colimg_BGR[2](cv::Range(patch_up, patch_down + 1), cv::Range(patch_left, patch_right + 1));
	curPatch2 = colimg_BGR[1](cv::Range(patch_up, patch_down + 1), cv::Range(patch_left, patch_right + 1));
	curPatch3 = colimg_BGR[0](cv::Range(patch_up, patch_down + 1), cv::Range(patch_left, patch_right + 1));
	
	coldiff = cv::Mat(patch_h, patch_w, CV_64F);
	coldiff = (centercol1 - curPatch1).mul(centercol1 - curPatch1) + (centercol2 - curPatch2).mul(centercol2 - curPatch2) + (centercol3 - curPatch3).mul(centercol3 - curPatch3);
	cv::sqrt(coldiff, coldiff);
	
	xones = cv::Mat::ones(patch_h, patch_w, CV_32S)*x;
	yones = cv::Mat::ones(patch_h, patch_w, CV_32S)*y;
	sdiff = cv::Mat(patch_h, patch_w, CV_32S);
	sdiff = (xones - patchXinds).mul(xones - patchXinds) + (yones - patchYinds).mul(yones - patchYinds);
	sdiff.convertTo(sdiff, CV_64F);
	cv::sqrt(sdiff, sdiff);
	maskVals = cv::Mat(patch_h, patch_w, CV_64F);
	temp1 = cv::Mat(patch_h, patch_w, CV_64F);
	temp2 = cv::Mat(patch_h, patch_w, CV_64F);
	cv::exp(-1*coldiff/(gamma_c*gamma_c), temp1);
	cv::exp(-1*sdiff/(gamma_p*gamma_p), temp2);
	maskVals = temp1.mul(temp2);
	
	dispVals = disp_img_copy(cv::Range(patch_up, patch_down + 1), cv::Range(patch_left, patch_right + 1));
	cv::minMaxLoc(dispVals, NULL, &maxDispVal_tmp);
	maxDispVal = (int)maxDispVal_tmp;
	
	
	
	// Make histogram
	
	for(i = 0; i < maxDispVal; i++){
	  hist[i] = 0;
	}
	
	for(i = 0; i < patch_h; i++){
	  for(j = 0; j < patch_w; j++){
	      hist[dispVals.at<int>(i,j)-1] += maskVals.at<double>(i,j);
	  }
	}
	hist_sum = hist[0];
	
	memcpy(hist_cumsum, hist, sizeof(double)*maxDispVal);
	for(i = 1; i < maxDispVal; i++){
	  hist_sum += hist[i];
	  hist_cumsum[i] += hist_cumsum[i-1];
	}
	
	for(i = 0; i < maxDispVal; i++){
	  if(hist_cumsum[i] > hist_sum/2.0){
	    medianFiltered_tmp.at<int>(y,x) = i+1;
	    break;
	  }
	}
	
	
	
	
      }
    }
  }

  delete [] hist;
  delete [] hist_cumsum;

  delete [] colimg_BGR;

  *medianFiltered = cv::Mat(h, w, CV_32S);
  *medianFiltered = medianFiltered_tmp;

  t1 = clock();
  printf("weightedmedian %f [sec]\n", (double)(t1-t0)/CLOCKS_PER_SEC);
}



void fillPixelsReference(cv::Mat *Il, cv::Mat *final_labels, double gamma_c, double gamma_d, int r_median, int numDisp, cv::Mat *output_labels){

  int m = final_labels->rows;
  int n = final_labels->cols;

  cv::Mat final_labels_copy = cv::Mat(m, n, CV_32S);
  cv::Mat occPix = cv::Mat(m, n, CV_8U);

  final_labels_copy = *final_labels;
  occPix = final_labels_copy < 0;

  // Streak-based filling of invalidated pixels from left
  int col;
  cv::Mat fillVals = cv::Mat::ones(m, 1, CV_32S)*numDisp;
  cv::Mat final_labels_filled;
  final_labels_copy.copyTo(final_labels_filled);

  cv::Mat curCol = cv::Mat(m, 1, CV_32S);
  cv::Mat mask = cv::Mat(m, 1, CV_8U);
  for(col = 0; col < n; col++){
    final_labels_copy.col(col).copyTo(curCol);
    mask = curCol == -1;
    fillVals.copyTo(curCol, mask);
    mask = curCol != -1;
    curCol.copyTo(fillVals, mask);
    curCol.copyTo(final_labels_filled.col(col));
  }
    
  // Streak-based filling of invalidated pixels from right
  fillVals = cv::Mat::ones(m, 1, CV_32S)*numDisp;
  cv::Mat final_labels_filled1;
  final_labels_copy.copyTo(final_labels_filled1);
  for(col = n-1; col >= 0; col--){
    final_labels_copy.col(col).copyTo(curCol);
    mask = curCol == -1;
    fillVals.copyTo(curCol, mask);
    mask = curCol != -1;
    curCol.copyTo(fillVals, mask);
    curCol.copyTo(final_labels_filled1.col(col));
  }

  // Choose minimum disparity
  cv::Mat output_labels_tmp = cv::Mat(m, n, CV_32S);
  cv::min(final_labels_filled, final_labels_filled1, output_labels_tmp);

  //Weighted median filtering on occluded regions (post processing)
  cv::Mat final_labels_smoothed;
  weightedMedian(Il, &output_labels_tmp, &occPix, r_median, gamma_c, gamma_d, numDisp, &final_labels_smoothed);
  final_labels_smoothed.copyTo(output_labels_tmp, occPix);
  *output_labels = cv::Mat(m, n, CV_32S);
  *output_labels = output_labels_tmp;

}
  





void guidedfilter_color(cv::Mat *I, cv::Mat *p, cv::Mat *q, int r, double eps){
  cv::Mat N, mean_I_r, mean_I_g, mean_I_b, mean_p, mean_Ip_r, mean_Ip_g, mean_Ip_b, cov_Ip_r, cov_Ip_g, cov_Ip_b, var_I_rr, var_I_rg, var_I_rb, var_I_gg, var_I_gb, var_I_bb;

  int x, y, hei, wid;
  int kernelr = 2*r+1;

  hei = I->rows;
  wid = I->cols;
  cv::Mat ones = cv::Mat::ones(hei, wid, CV_64F);

  cv::boxFilter(ones, N, CV_64F, cv::Size(kernelr,kernelr), cv::Point(-1,-1), false, cv::BORDER_CONSTANT);

  cv::Mat *BGR = new cv::Mat[3];
  cv::split(*I, BGR);

  cv::boxFilter(BGR[2], mean_I_r, CV_64F, cv::Size(kernelr, kernelr), cv::Point(-1,-1), false, cv::BORDER_CONSTANT);
  mean_I_r = mean_I_r / N;
  
  cv::boxFilter(BGR[1], mean_I_g, CV_64F, cv::Size(kernelr, kernelr), cv::Point(-1,-1), false, cv::BORDER_CONSTANT);
  mean_I_g = mean_I_g / N;


  cv::boxFilter(BGR[0], mean_I_b, CV_64F, cv::Size(kernelr, kernelr), cv::Point(-1,-1), false, cv::BORDER_CONSTANT);
  mean_I_b = mean_I_b / N;


  cv::boxFilter(*p, mean_p, CV_64F, cv::Size(kernelr, kernelr), cv::Point(-1,-1), false, cv::BORDER_CONSTANT);
  mean_p = mean_p / N;

  
  cv::boxFilter(BGR[2].mul(*p), mean_Ip_r, CV_64F, cv::Size(kernelr, kernelr), cv::Point(-1,-1), false, cv::BORDER_CONSTANT);
  mean_Ip_r = mean_Ip_r / N;
  
  cv::boxFilter(BGR[1].mul(*p), mean_Ip_g, CV_64F, cv::Size(kernelr, kernelr), cv::Point(-1,-1), false, cv::BORDER_CONSTANT);
  mean_Ip_g = mean_Ip_g / N;

  cv::boxFilter(BGR[0].mul(*p), mean_Ip_b, CV_64F, cv::Size(kernelr, kernelr), cv::Point(-1,-1), false, cv::BORDER_CONSTANT);
  mean_Ip_b = mean_Ip_b / N;
  

  cov_Ip_r = mean_Ip_r - mean_I_r.mul(mean_p);
  cov_Ip_g = mean_Ip_g - mean_I_g.mul(mean_p);
  cov_Ip_b = mean_Ip_b - mean_I_b.mul(mean_p);


  cv::boxFilter(BGR[2].mul(BGR[2]), var_I_rr, CV_64F, cv::Size(kernelr, kernelr), cv::Point(-1,-1), false, cv::BORDER_CONSTANT);
  var_I_rr = var_I_rr / N - mean_I_r.mul(mean_I_r);

  cv::boxFilter(BGR[2].mul(BGR[1]), var_I_rg, CV_64F, cv::Size(kernelr, kernelr), cv::Point(-1,-1), false, cv::BORDER_CONSTANT);
  var_I_rg = var_I_rg / N - mean_I_r.mul(mean_I_g);

  cv::boxFilter(BGR[2].mul(BGR[0]), var_I_rb, CV_64F, cv::Size(kernelr, kernelr), cv::Point(-1,-1), false, cv::BORDER_CONSTANT);
  var_I_rb = var_I_rb / N - mean_I_r.mul(mean_I_b);

  cv::boxFilter(BGR[1].mul(BGR[1]), var_I_gg, CV_64F, cv::Size(kernelr, kernelr), cv::Point(-1,-1), false, cv::BORDER_CONSTANT);
  var_I_gg = var_I_gg / N - mean_I_g.mul(mean_I_g);

  cv::boxFilter(BGR[1].mul(BGR[0]), var_I_gb, CV_64F, cv::Size(kernelr, kernelr), cv::Point(-1,-1), false, cv::BORDER_CONSTANT);
  var_I_gb = var_I_gb / N - mean_I_g.mul(mean_I_b);

  cv::boxFilter(BGR[0].mul(BGR[0]), var_I_bb, CV_64F, cv::Size(kernelr, kernelr), cv::Point(-1,-1), false, cv::BORDER_CONSTANT);
  var_I_bb = var_I_bb / N - mean_I_b.mul(mean_I_b);


  cv::Mat a0 = cv::Mat::zeros(hei, wid, CV_64F);
  cv::Mat a1 = cv::Mat::zeros(hei, wid, CV_64F);
  cv::Mat a2 = cv::Mat::zeros(hei, wid, CV_64F);
  

  cv::Mat Sigma = cv::Mat(3,3,CV_64F);;
  cv::Mat cov_Ip;
  cv::Mat temp = cv::Mat(1,3,CV_64F);
  for(y=0; y<hei; y++){
    for(x=0; x<wid; x++){
      Sigma.at<double>(0,0) = var_I_rr.at<double>(y,x);
      Sigma.at<double>(0,1) = var_I_rg.at<double>(y,x);
      Sigma.at<double>(0,2) = var_I_rb.at<double>(y,x);
      Sigma.at<double>(1,0) = var_I_rg.at<double>(y,x);
      Sigma.at<double>(1,1) = var_I_gg.at<double>(y,x);
      Sigma.at<double>(1,2) = var_I_gb.at<double>(y,x);
      Sigma.at<double>(2,0) = var_I_rb.at<double>(y,x);
      Sigma.at<double>(2,1) = var_I_gb.at<double>(y,x);
      Sigma.at<double>(2,2) = var_I_bb.at<double>(y,x);

      cov_Ip = (cv::Mat_<double>(1,3) << cov_Ip_r.at<double>(y,x), cov_Ip_g.at<double>(y,x), cov_Ip_b.at<double>(y,x));

      temp = cov_Ip*((Sigma + eps*(cv::Mat::eye(3,3,CV_64F))).inv());

      a0.at<double>(y,x)=temp.at<double>(0,0);
      a1.at<double>(y,x)=temp.at<double>(0,1);
      a2.at<double>(y,x)=temp.at<double>(0,2);
    }
  }


  cv::Mat b = cv::Mat(hei, wid, CV_64F);
  b = mean_p - a0.mul(mean_I_r) - a1.mul(mean_I_g) - a2.mul(mean_I_b);

  cv::Mat temp0, temp1, temp2, temp3;
  cv::boxFilter(a0, temp0, CV_64F, cv::Size(kernelr, kernelr), cv::Point(-1,-1), false, cv::BORDER_CONSTANT);
  cv::boxFilter(a1, temp1, CV_64F, cv::Size(kernelr, kernelr), cv::Point(-1,-1), false, cv::BORDER_CONSTANT);
  cv::boxFilter(a2, temp2, CV_64F, cv::Size(kernelr, kernelr), cv::Point(-1,-1), false, cv::BORDER_CONSTANT);
  cv::boxFilter(b, temp3, CV_64F, cv::Size(kernelr, kernelr), cv::Point(-1,-1), false, cv::BORDER_CONSTANT);

  *q = cv::Mat(hei, wid, CV_64F);
  *q = (temp0.mul(BGR[2]) + temp1.mul(BGR[1]) + temp2.mul(BGR[0]) + temp3)/N;

  delete [] BGR;

}









void firstCVF(cv::Mat& IlS, cv::Mat& IrS, cv::Mat& Il, int r, double eps, double thresColor, double thresGrad, double gamma, double threshBorder, int numLabels, double scale, int sign, cv::Mat& output){

  clock_t t0, t1;
  t0 = clock();


  int i, j;

  int XMARGIN = numLabels;

  int m = Il.rows;
  int n = Il.cols;

  int mS = IlS.rows;
  int nS = IlS.cols;
  int cS = IlS.channels();

  IlS.convertTo(IlS, CV_32F);
  IrS.convertTo(IrS, CV_32F);

  cv::Mat Il_g, Ir_g, fx_l, fx_r;

  // Convert to grayscale
  cv::cvtColor(IlS, Il_g, CV_RGB2GRAY);
  cv::cvtColor(IrS, Ir_g, CV_RGB2GRAY);

  IlS.convertTo(IlS, CV_64F);
  IrS.convertTo(IrS, CV_64F);

  Il_g.convertTo(Il_g, CV_64F);
  Ir_g.convertTo(Ir_g, CV_64F);


  // Compute gradient in X-direction from grayscale images
  cv::Sobel(Il_g, fx_l, CV_64F, 1, 0, 1, 0.5, 0, cv::BORDER_REPLICATE);
  cv::Sobel(Ir_g, fx_r, CV_64F, 1, 0, 1, 0.5, 0, cv::BORDER_REPLICATE);

  
  for(i = 0; i < fx_l.rows; i++){
    fx_l.at<double>(i,0) *= 2;
    fx_l.at<double>(i,fx_l.cols-1) *= 2;
    fx_r.at<double>(i,0) *= 2;
    fx_r.at<double>(i,fx_r.cols-1) *= 2;
  }

  

  fx_l += 0.5; // To get a range of values between 0 to 1
  fx_r += 0.5;

 
  cv::Mat *Il_BGR = new cv::Mat[3];
  cv::Mat *Ir_BGR = new cv::Mat[3];

  cv::Mat p_color, p_grad, tmp_0, tmp_1, tmp_2, ones_0, ones_1, ones_2;

  cv::split(IlS, Il_BGR);
  cv::split(IrS, Ir_BGR);

  ones_0 = cv::Mat::ones(mS,nS+XMARGIN*2,CV_64F);
  ones_1 = cv::Mat::ones(mS,nS+XMARGIN*2,CV_64F);
  ones_2 = cv::Mat::ones(mS,nS+XMARGIN*2,CV_64F);
    

  int d;
  cv::Rect Margin = cv::Rect(XMARGIN, 0, nS, mS);
  cv::Rect rect;

  cv::Mat currentCost = cv::Mat::ones(m, n, CV_64F)*100.0; // Initialized by invalid cost
  cv::Mat currentLabel = cv::Mat(m, n, CV_32S);
  cv::Mat q, updateMask;


  // Make cost-slice for every disparity
  for(d = 1; d <= numLabels; d++){

    // Truncated SAD of color images for current displacement
    tmp_0 = ones_0*threshBorder;
    tmp_1 = ones_1*threshBorder;
    tmp_2 = ones_2*threshBorder;

    rect = cv::Rect(XMARGIN+sign*d, 0, nS, mS);

    Ir_BGR[2].copyTo(tmp_0(rect));
    Ir_BGR[1].copyTo(tmp_1(rect));
    Ir_BGR[0].copyTo(tmp_2(rect));

    tmp_0(Margin).copyTo(tmp_0);
    tmp_1(Margin).copyTo(tmp_1);
    tmp_2(Margin).copyTo(tmp_2);
    
    p_color = cv::abs(tmp_0 - Il_BGR[2]) + cv::abs(tmp_1 - Il_BGR[1]) + cv::abs(tmp_2 - Il_BGR[0]);
    cv::resize(p_color, p_color, cv::Size(n,m), 0, 0, cv::INTER_NEAREST);
    p_color = p_color / 3.0;
    p_color = cv::min(p_color, thresColor);


    // Truncated SAD of gradient images for current displacement
    tmp_0 = ones_0*threshBorder;

    fx_r.copyTo(tmp_0(rect));

    tmp_0(Margin).copyTo(tmp_0);


    p_grad = cv::abs(tmp_0 - fx_l);
    cv::resize(p_grad, p_grad, cv::Size(n,m), 0, 0, cv::INTER_NEAREST);
    p_grad = cv::min(p_grad, thresGrad);

    cv::Mat p = gamma*p_color + (1-gamma)*p_grad; // Combined color and gradient

    guidedfilter_color(&Il, &p, &q, r, eps);

    updateMask = q < currentCost;
    q.copyTo(currentCost, updateMask);
    for(i = 0; i < m; i++){
      for(j = 0; j < n; j++){
	if(updateMask.at<uchar>(i,j)){
	  currentLabel.at<int>(i,j) = d;
	}
      }
    }

  }

  delete [] Il_BGR;
  delete [] Ir_BGR;

  currentLabel.copyTo(output);


  t1 = clock();
  printf("firstCVF %f [sec]\n", (double)(t1-t0)/CLOCKS_PER_SEC);

}












void hiearchicalCVF(cv::Mat& lowerOutput, double downScale, cv::Mat& SuperPixelsLower, cv::Mat& SuperPixels, struct SP_loc *SP_locs_lower, struct SP_loc *SP_locs, int numSPs, int numLabelsLower, cv::Mat& IlS, cv::Mat& IrS, cv::Mat& Il, int r, double eps, double thresColor, double thresGrad, double gamma, double threshBorder, int numLabels, double scale, int sign, cv::Mat& output){

  clock_t t0, t1;
  t0 = clock();

  lowerOutput.convertTo(lowerOutput, CV_32F);

  int i, j, k, x, y;

  int XMARGIN = numLabels;

  int m = Il.rows;
  int n = Il.cols;

  int mS = IlS.rows;
  int nS = IlS.cols;
  int cS = IlS.channels();

  IlS.convertTo(IlS, CV_32F);
  IrS.convertTo(IrS, CV_32F);

  cv::Mat Il_g, Ir_g, fx_l, fx_r;

  // Convert to grayscale
  cv::cvtColor(IlS, Il_g, CV_BGR2GRAY);
  cv::cvtColor(IrS, Ir_g, CV_BGR2GRAY);

  IlS.convertTo(IlS, CV_64F);
  IrS.convertTo(IrS, CV_64F);

  Il_g.convertTo(Il_g, CV_64F);
  Ir_g.convertTo(Ir_g, CV_64F);


  // Compute gradient in X-direction from grayscale images
  cv::Sobel(Il_g, fx_l, CV_64F, 1, 0, 1, 0.5, 0, cv::BORDER_REPLICATE);
  cv::Sobel(Ir_g, fx_r, CV_64F, 1, 0, 1, 0.5, 0, cv::BORDER_REPLICATE);
  
  for(i = 0; i < fx_l.rows; i++){
    fx_l.at<double>(i,0) *= 2;
    fx_l.at<double>(i,fx_l.cols-1) *= 2;
    fx_r.at<double>(i,0) *= 2;
    fx_r.at<double>(i,fx_r.cols-1) *= 2;
  }

  

  fx_l += 0.5; // To get a range of values between 0 to 1
  fx_r += 0.5;

 
  cv::Mat *Il_BGR = new cv::Mat[3];
  cv::Mat *Ir_BGR = new cv::Mat[3];

  cv::Mat p_color, p_grad, tmp_0, tmp_1, tmp_2, ones_0, ones_1, ones_2;

  cv::split(IlS, Il_BGR);
  cv::split(IrS, Ir_BGR);

    
  int d;
  cv::Rect MarginCut, rect, flowRect, patchS, patch;

  cv::Mat currentCost = cv::Mat::ones(m, n, CV_64F)*100.0; // Initialized by invalid cost
  cv::Mat currentLabel = cv::Mat(m, n, CV_32S);
  cv::Mat q, updateMask, Il_patch;

  cv::Mat mask, curGrid;


  int histSize[] = {numLabelsLower};

  float hrange[] = {1, numLabelsLower+1};

  const float* ranges[] = {hrange};
  cv::Mat hist;

  int supportRange = ((int)(0.5/downScale+0.5))*scale;   // Range of support labels (support disparities)
  int labelRangeMargin = supportRange*2;

  cv::Mat validMap; // express wheather each label is included in candidate or not, 1 is valid, 0 is invalid
  cv::Mat Zeros = cv::Mat::zeros(numLabels+labelRangeMargin*2, 1, CV_8U);


  int patchU, patchD, patchL, patchR, patchH, patchW;
  int patchSU, patchSD, patchSL, patchSR, patchSH, patchSW;
  int patchIrSL, patchIrSR, patchIrSU, patchIrSD, patchIrSH, patchIrSW;

  cv::Mat Ir_BGR2withMargin = cv::Mat::ones(mS, nS+XMARGIN*2+1, CV_64F)*threshBorder;
  cv::Mat Ir_BGR1withMargin = cv::Mat::ones(mS, nS+XMARGIN*2+1, CV_64F)*threshBorder;
  cv::Mat Ir_BGR0withMargin = cv::Mat::ones(mS, nS+XMARGIN*2+1, CV_64F)*threshBorder;

  Ir_BGR[2].copyTo(Ir_BGR2withMargin(cv::Rect(XMARGIN, 0, nS, mS)));
  Ir_BGR[1].copyTo(Ir_BGR1withMargin(cv::Rect(XMARGIN, 0, nS, mS)));
  Ir_BGR[0].copyTo(Ir_BGR0withMargin(cv::Rect(XMARGIN, 0, nS, mS)));


  cv::Mat fx_rWithMargin = cv::Mat::ones(mS, nS+XMARGIN*2+1, CV_64F)*threshBorder;

  fx_r.copyTo(fx_rWithMargin(cv::Rect(XMARGIN, 0, nS, mS)));

  // In every local region
  for(i = 0; i < numSPs; i++){
      

    if(SP_locs_lower[i].up <= SP_locs_lower[i].down && SP_locs_lower[i].left <= SP_locs_lower[i].right){

      // Make histgram of labels in current local region in lower output
      SuperPixelsLower(cv::Range(SP_locs_lower[i].up, SP_locs_lower[i].down+1), cv::Range(SP_locs_lower[i].left, SP_locs_lower[i].right+1)).copyTo(curGrid);

      mask = curGrid == i;
      lowerOutput(cv::Range(SP_locs_lower[i].up, SP_locs_lower[i].down+1), cv::Range(SP_locs_lower[i].left, SP_locs_lower[i].right+1)).copyTo(curGrid);

      cv::calcHist(&curGrid, 1, 0, mask, hist, 1, histSize, ranges);


      Zeros.copyTo(validMap);

      // Select candidate labels
      for(y = 1; y <= numLabelsLower; y++){
	if(hist.at<float>(y-1,0) > 0){
	  
	  for(j = -supportRange; j <= supportRange; j++){
	    validMap.at<uchar>(y/downScale+j+labelRangeMargin, 0) = 1;
	  }
	  
	}
      }
 
      patchU = std::max(0, SP_locs[i].up-r);
      patchD = std::min(m-1, SP_locs[i].down+r);
      patchL = std::max(0, SP_locs[i].left-r);
      patchR = std::min(n-1, SP_locs[i].right+r);

      patchH = patchD - patchU + 1;
      patchW = patchR - patchL + 1;

      patch = cv::Rect(patchL, patchU, patchW, patchH);


      patchSU = patchU*scale;
      patchSD = std::min(mS-1, (patchD+1)*(int)scale-1);
      patchSL = patchL*scale;
      patchSR = std::min(nS-1, (patchR+1)*(int)scale-1);

      patchSH = patchSD - patchSU + 1;
      patchSW = patchSR - patchSL + 1;


      patchS = cv::Rect(patchSL, patchSU, patchSW, patchSH);
      MarginCut = cv::Rect(XMARGIN*2, 0, patchSW, patchSH);



      patchIrSU = patchSU;
      patchIrSD = patchSD;
      patchIrSL = patchSL+XMARGIN;
      patchIrSR = patchSR+XMARGIN;

      patchIrSH = patchIrSD - patchIrSU + 1;
      patchIrSW = patchIrSR - patchIrSL + 1;

      rect = cv::Rect(patchIrSL-XMARGIN, patchIrSU, patchIrSW+XMARGIN*2, patchIrSH);

      ones_0 = cv::Mat::ones(patchSH, patchSW+XMARGIN*4, CV_64F);
      ones_1 = cv::Mat::ones(patchSH, patchSW+XMARGIN*4, CV_64F);
      ones_2 = cv::Mat::ones(patchSH, patchSW+XMARGIN*4, CV_64F);

      Il(patch).copyTo(Il_patch);

      // Cost aggregation for every label
      for(d = 1; d <= numLabels; d++){

	if(validMap.at<uchar>(d+labelRangeMargin, 0) > 0){

	  // Truncated SAD of color images for current displacement
	  tmp_0 = ones_0*threshBorder;
	  tmp_1 = ones_1*threshBorder;
	  tmp_2 = ones_2*threshBorder;
	  
	  flowRect = cv::Rect(XMARGIN+sign*d, 0, patchIrSW+XMARGIN*2, patchIrSH);

	  Ir_BGR2withMargin(rect).copyTo(tmp_0(flowRect));
	  Ir_BGR1withMargin(rect).copyTo(tmp_1(flowRect));
	  Ir_BGR0withMargin(rect).copyTo(tmp_2(flowRect));


	  tmp_0(MarginCut).copyTo(tmp_0);
	  tmp_1(MarginCut).copyTo(tmp_1);
	  tmp_2(MarginCut).copyTo(tmp_2);

	  p_color = cv::abs(tmp_0 - Il_BGR[2](patchS)) + cv::abs(tmp_1 - Il_BGR[1](patchS)) + cv::abs(tmp_2 - Il_BGR[0](patchS));

	  cv::resize(p_color, p_color, Il_patch.size(), 0, 0, cv::INTER_NEAREST);
	  p_color = p_color / 3.0;
	  p_color = cv::min(p_color, thresColor);



	  
	  
	  // Truncated SAD of gradient images for current displacement
	  tmp_0 = ones_0*threshBorder;

	  fx_rWithMargin(rect).copyTo(tmp_0(flowRect));

	  tmp_0(MarginCut).copyTo(tmp_0);

	  p_grad = cv::abs(tmp_0 - fx_l(patchS));
	  cv::resize(p_grad, p_grad, Il_patch.size(), 0, 0, cv::INTER_NEAREST);
	  p_grad = cv::min(p_grad, thresGrad);


	  
	  cv::Mat p = gamma*p_color + (1-gamma)*p_grad; // Combined color and gradient

	  guidedfilter_color(&Il_patch, &p, &q, r, eps);
	  updateMask = q < currentCost(patch);
	  q.copyTo(currentCost(patch), updateMask);
	  for(y = patchU; y <= patchD; y++){
	    for(x = patchL; x <= patchR; x++){
	      if(updateMask.at<uchar>(y-patchU,x-patchL)){
		currentLabel.at<int>(y,x) = d;
	      }
	    }
	  }

	}
      }


    }
  }

  delete [] Il_BGR;
  delete [] Ir_BGR;

  currentLabel.copyTo(output);


  t1 = clock();
  printf("hiearchicalCVF %f [sec]\n", (double)(t1-t0)/CLOCKS_PER_SEC);

}

















int main(){
  int r = 9;  // radius of guided filter
  double eps = 0.0001;
  double thresColor = 7.0/255;
  double thresGrad = 2.0/255;
  double gamma = 0.11;
  double threshBorder = 3.0/255;
  double gamma_c = 0.1;
  double gamma_d = 9.0;
  int r_median = 19; // size of the kernel of weighted median filtering
  int k = 100; // number of Super-Pixels
  double mWeight = 10; // weight between color term and space one when making super-pixels (not used)

  int maxDisp = 60; // max disparity

  double scale = 1.0; // upsampling scale for sub-pixel accuracy
  double downScale = 0.5; // downsampling scale for coarse-to-fine process 

  int factor = 4; // scaling factor when saving output disparity map

  char *filenamel, *filenamer;


  filenamel = "im2.ppm";
  filenamer = "im6.ppm";
 

  cv::Mat Il = cv::imread(filenamel,1);
  cv::Mat Ir = cv::imread(filenamer,1);

  if(Il.data == NULL){
    std::cout << "cannot read " << filenamel << std::endl;
    exit(0);
  }
  if(Ir.data == NULL){
    std::cout << "cannot read " << filenamer << std::endl;
    exit(0);
  }


  clock_t t0, t1;
  t0 = clock();
  

  cv::Mat SuperPixels, SuperPixelsR;
  int numSPs, numSPsR;


  // Make super-pixels
  PerformSLICO(&Il, k, mWeight, &SuperPixels, &numSPs);
  PerformSLICO(&Ir, k, mWeight, &SuperPixelsR, &numSPsR);


  Il.convertTo(Il, CV_64F);
  Ir.convertTo(Ir, CV_64F);

  Il /= 255;
  Ir /= 255;

  // Upsample input images for sub-pixel accuracy
  cv::Mat IlS, IrS;
  cv::resize(Il, IlS, cv::Size(), scale, scale, cv::INTER_CUBIC);
  cv::resize(Ir, IrS, cv::Size(), scale, scale, cv::INTER_CUBIC);



  /////////////////////////////////////////////////
  // Must rewrite here if downscale != 0.5
  // Downsample input images for coarse-to-fine process
  std::vector<cv::Mat> IlS_pyramid;
  cv::buildPyramid(IlS, IlS_pyramid, 3);

  std::vector<cv::Mat> IrS_pyramid;
  cv::buildPyramid(IrS, IrS_pyramid, 3);

  std::vector<cv::Mat> Il_pyramid;
  cv::buildPyramid(Il, Il_pyramid, 3);

  std::vector<cv::Mat> Ir_pyramid;
  cv::buildPyramid(Ir, Ir_pyramid, 3);
  ////////////////////////////////////////////////




  cv::Mat* SP_pyramid = new cv::Mat[4];
  cv::Mat* SP_pyramidR = new cv::Mat[4];

  // Downsample super-pixels for coarse-to-fine process
  SP_pyramid[0] = SuperPixels;
  cv::resize(SP_pyramid[0], SP_pyramid[1], cv::Size(Il_pyramid[1].cols, Il_pyramid[1].rows), 0, 0, cv::INTER_NEAREST);
  cv::resize(SP_pyramid[1], SP_pyramid[2], cv::Size(Il_pyramid[2].cols, Il_pyramid[2].rows), 0, 0, cv::INTER_NEAREST);
  cv::resize(SP_pyramid[2], SP_pyramid[3], cv::Size(Il_pyramid[3].cols, Il_pyramid[3].rows), 0, 0, cv::INTER_NEAREST);


  SP_pyramidR[0] = SuperPixelsR;
  cv::resize(SP_pyramidR[0], SP_pyramidR[1], cv::Size(Ir_pyramid[1].cols, Ir_pyramid[1].rows), 0, 0, cv::INTER_NEAREST);
  cv::resize(SP_pyramidR[1], SP_pyramidR[2], cv::Size(Ir_pyramid[2].cols, Ir_pyramid[2].rows), 0, 0, cv::INTER_NEAREST);
  cv::resize(SP_pyramidR[2], SP_pyramidR[3], cv::Size(Ir_pyramid[3].cols, Ir_pyramid[3].rows), 0, 0, cv::INTER_NEAREST);


  // locations of every super-pixel
  struct SP_loc *SP_locs0 = new struct SP_loc[numSPs];  
  struct SP_loc *SP_locs1 = new struct SP_loc[numSPs];
  struct SP_loc *SP_locs2 = new struct SP_loc[numSPs];
  struct SP_loc *SP_locs3 = new struct SP_loc[numSPs];

  getSPloc(SP_pyramid[0], SP_locs0, numSPs);
  getSPloc(SP_pyramid[1], SP_locs1, numSPs);
  getSPloc(SP_pyramid[2], SP_locs2, numSPs);
  getSPloc(SP_pyramid[3], SP_locs3, numSPs);
  
  

  struct SP_loc *SP_locs0R = new struct SP_loc[numSPsR];  
  struct SP_loc *SP_locs1R = new struct SP_loc[numSPsR];
  struct SP_loc *SP_locs2R = new struct SP_loc[numSPsR];
  struct SP_loc *SP_locs3R = new struct SP_loc[numSPsR];

  getSPloc(SP_pyramidR[0], SP_locs0R, numSPsR);
  getSPloc(SP_pyramidR[1], SP_locs1R, numSPsR);
  getSPloc(SP_pyramidR[2], SP_locs2R, numSPsR);
  getSPloc(SP_pyramidR[3], SP_locs3R, numSPsR);



  int maxDispS = maxDisp*scale;
  int maxDispS1 = (maxDispS + 1)/2;
  int maxDispS2 = (maxDispS1 + 1)/2;
  int maxDispS3 = (maxDispS2 + 1)/2;


  // Perform coarse-to-fine CVF in each scale

  // for left image
  cv::Mat labels_left3;
  firstCVF(IlS_pyramid[3], IrS_pyramid[3], Il_pyramid[3], r, eps, thresColor, thresGrad, gamma, threshBorder, maxDispS3, scale, 1, labels_left3);

  // for right image
  cv::Mat labels_right3;
  firstCVF(IrS_pyramid[3], IlS_pyramid[3], Ir_pyramid[3], r, eps, thresColor, thresGrad, gamma, threshBorder, maxDispS3, scale, -1, labels_right3);



  cv::Mat labels_left2;
  hiearchicalCVF(labels_left3, downScale, SP_pyramid[3], SP_pyramid[2], SP_locs3, SP_locs2, numSPs, maxDispS3, IlS_pyramid[2], IrS_pyramid[2], Il_pyramid[2], r, eps, thresColor, thresGrad, gamma, threshBorder, maxDispS2, scale, 1, labels_left2);


  cv::Mat labels_right2;
  hiearchicalCVF(labels_right3, downScale, SP_pyramidR[3], SP_pyramidR[2], SP_locs3R, SP_locs2R, numSPsR, maxDispS3, IrS_pyramid[2], IlS_pyramid[2], Ir_pyramid[2], r, eps, thresColor, thresGrad, gamma, threshBorder, maxDispS2, scale, -1, labels_right2);


  cv::Mat labels_left1;
  hiearchicalCVF(labels_left2, downScale, SP_pyramid[2], SP_pyramid[1], SP_locs2, SP_locs1, numSPs, maxDispS2, IlS_pyramid[1], IrS_pyramid[1], Il_pyramid[1], r, eps, thresColor, thresGrad, gamma, threshBorder, maxDispS1, scale, 1, labels_left1);


  cv::Mat labels_right1;
  hiearchicalCVF(labels_right2, downScale, SP_pyramidR[2], SP_pyramidR[1], SP_locs2R, SP_locs1R, numSPsR, maxDispS2, IrS_pyramid[1], IlS_pyramid[1], Ir_pyramid[1], r, eps, thresColor, thresGrad, gamma, threshBorder, maxDispS1, scale, -1, labels_right1);




 cv::Mat labels_left;
  hiearchicalCVF(labels_left1, downScale, SP_pyramid[1], SP_pyramid[0], SP_locs1, SP_locs0, numSPs, maxDispS1, IlS_pyramid[0], IrS_pyramid[0], Il_pyramid[0], r, eps, thresColor, thresGrad, gamma, threshBorder, maxDispS, scale, 1, labels_left);


  cv::Mat labels_right;
  hiearchicalCVF(labels_right1, downScale, SP_pyramidR[1], SP_pyramidR[0], SP_locs1R, SP_locs0R, numSPsR, maxDispS1, IrS_pyramid[0], IlS_pyramid[0], Ir_pyramid[0], r, eps, thresColor, thresGrad, gamma, threshBorder, maxDispS, scale, -1, labels_right);


  cv::Mat labels_left_round;
  labels_left.convertTo(labels_left_round, CV_32S, 1/scale);


  

  // Left-right consistency check
  int m = Il.rows;
  int n = Il.cols;

  cv::Mat temp = cv::Mat(m,1,CV_32S);
  cv::Mat temp1 = cv::Mat(1,n,CV_32S);
  cv::Mat final_labels = labels_left;

  int i, j;

 
  for(i = 0; i < m; i++){
    temp.at<int>(i,0) = i;
  }
  for(j = 0; j < n; j++){
    temp1.at<int>(0,j) = j;
  }
  cv::Mat X = cv::Mat(m,n,CV_32S);
  cv::Mat Y = cv::Mat(m,n,CV_32S);
  cv::repeat(temp, 1, n, Y);
  cv::repeat(temp1, m, 1, X);
  X = X -labels_left_round;
  for(i = 0; i < m; i++){
    for(j = 0; j < n; j++){
      if(X.at<int>(i,j) < 0){
        X.at<int>(i,j) = 0;
      }
      if(labels_left.at<int>(i,j) - labels_right.at<int>(Y.at<int>(i,j), X.at<int>(i,j)) >= scale || labels_left.at<int>(i,j) - labels_right.at<int>(Y.at<int>(i,j), X.at<int>(i,j)) <= -scale){
        final_labels.at<int>(i,j) = -1;
      }
    }
  }
  

  cv::Mat inputLabels;
  final_labels.copyTo(inputLabels);


  // Fill and filter (post-process) pixels that fail the consistency check
  fillPixelsReference(&Il, &inputLabels, gamma_c, gamma_d, r_median, maxDispS, &final_labels);
  
  final_labels.convertTo(final_labels, CV_64F, 1/scale);
  final_labels.convertTo(final_labels, CV_8U, factor);

  
  t1 = clock();
  printf("time without IO %f [sec]\n", (double)(t1-t0)/CLOCKS_PER_SEC);

  
  std::vector<int> param;
  param.push_back(CV_IMWRITE_PNG_COMPRESSION);
  param.push_back(0);


  cv::imwrite("result.png", final_labels, param);
  

  
  return 0;
}
